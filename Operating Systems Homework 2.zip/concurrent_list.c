#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "concurrent_list.h"

struct node {
    int value;
    struct node* next;
    pthread_mutex_t lock;
};

struct list {
    struct node* head;
    pthread_mutex_t lock;
};

void print_node(node* node) {
    if (node) {
        printf("%d ", node->value);
    }
}

list* create_list() {

    list* new_list = malloc(sizeof(list));
    if (!new_list) return NULL;

    new_list->head = NULL;
    pthread_mutex_init(&new_list->lock, NULL);
    return new_list;
}


void delete_list(list* list) {
    if (!list) return;

    pthread_mutex_lock(&list->lock);

    node* curr = list->head;
    while (curr != NULL) {
        node* next = curr->next;             // save the next node before we delete the current node
        pthread_mutex_destroy(&curr->lock);  // destroy the mutex
        free(curr);                  
        curr = next;                         
    }

    pthread_mutex_unlock(&list->lock);
    pthread_mutex_destroy(&list->lock);
    free(list);
}



void insert_value(list* list, int value) {

    if (!list) return;
        
   node* new_node = malloc(sizeof(node));
    if (!new_node) {

        return ;
    }
    new_node->value = value;// Initialize the node – and also its lock!
    // Each node must have a lock for fine-grained locking.

    new_node->next = NULL;
    pthread_mutex_init(&new_node->lock, NULL);

    pthread_mutex_lock(&list->lock);   // Why? Because head might be NULL (empty list), or needs to be updated if we insert at the head.

    node* curr = list->head;
    if (!curr || curr->value > value) {//Insert at the head of the list

        new_node->next = curr;
        list->head = new_node;
        pthread_mutex_unlock(&list->lock);
        return;
    }

    pthread_mutex_lock(&curr->lock);// Lock the mutex of the current node

    pthread_mutex_unlock(&list->lock);// If the list's lock wasn't released in the loop, unlock it here


    node* prev = NULL;
    while (curr && curr->value <= value) {
        if (prev)
            pthread_mutex_unlock(&prev->lock);//unlock the previous node
        prev = curr;                          // update the prev node t the current node
        curr = curr->next;                    //update the current node to the next node
        if (curr)
            pthread_mutex_lock(&curr->lock);  //lock the next node
    }

    new_node->next = curr;
    prev->next = new_node;
    pthread_mutex_unlock(&prev->lock);// unlock the two nodes between which the modification was done

    if (curr) pthread_mutex_unlock(&curr->lock);
}

void remove_value(list* list, int value) {
    if (!list) return;
    pthread_mutex_lock(&list->lock);
    node* curr = list->head;
    if (!curr) {
        pthread_mutex_unlock(&list->lock);
        return;
    }
    pthread_mutex_lock(&curr->lock);
    if (curr->value == value) {
        list->head = curr->next;
        pthread_mutex_unlock(&list->lock);
        pthread_mutex_unlock(&curr->lock);
        pthread_mutex_destroy(&curr->lock);
        free(curr);
        return;
    }

    node* prev = curr;
    curr = curr->next;
    if (curr)
        pthread_mutex_lock(&curr->lock);// Make sure that we have locked two next nodes  
    // Unlock the list's mutex since it's not empty and we're not going to modify the head
    pthread_mutex_unlock(&list->lock);

    while (curr && curr->value != value) {
        pthread_mutex_unlock(&prev->lock);// Unlock the previous node so we can advance the pointer to the next nodes.

        prev = curr;
        curr = curr->next;
        if (curr)
            pthread_mutex_lock(&curr->lock);// Lock the new node we are pointing to.

    }

    if (curr) {
        prev->next = curr->next;
        pthread_mutex_unlock(&curr->lock);
        pthread_mutex_destroy(&curr->lock);
        free(curr);
    }
    pthread_mutex_unlock(&prev->lock);  // We must keep 'prev' locked until the end, so that if we do end up deleting 'curr',
    // we can safely update prev->next = curr->next.


}

void print_list(list* list) {
    if (!list) return;
    pthread_mutex_lock(&list->lock);
    node* curr = list->head;
    if (curr) pthread_mutex_lock(&curr->lock);
    pthread_mutex_unlock(&list->lock);// אם הרשימה לא ריקה עושים נעילה לצומת הראשון ברשימה ומשחררים את הנעילה על הרשימה

    while (curr) {           // In the loop, we always lock the next node before unlocking the current one (curr),
        // to ensure thread-safe access to next nodes in a multithreaded environment.
       // In the last iteration of the loop, 'next' will be NULL,
      // so no new lock will be acquired—only the last locked node will be unlocked.
     // This guarantees that every node that was locked is also unlocked,
    // and no node remains locked at the end of the function.
       
            print_node(curr);
        node* next = curr->next;
        if (next) pthread_mutex_lock(&next->lock);
        pthread_mutex_unlock(&curr->lock);
        curr = next;
    }
    printf("\n");
}

void count_list(list* list, int (*predicate)(int)) {
    if (!list) return;
    int count = 0;
    pthread_mutex_lock(&list->lock);
    node* curr = list->head;
    if (curr) pthread_mutex_lock(&curr->lock);
    pthread_mutex_unlock(&list->lock);

    while (curr) {
        if (predicate(curr->value)) {
            count++;
        }
        node* next = curr->next;
        if (next) pthread_mutex_lock(&next->lock);
        pthread_mutex_unlock(&curr->lock);
        curr = next;
    }

    printf("%d items were counted\n", count);
}

void swap_values(list* list, int val1, int val2) {
    if (!list) return;
    if (val1 == val2) return; // There's no need to swap if the values are equal


    pthread_mutex_lock(&list->lock);
    node* curr = list->head;
    if (curr) pthread_mutex_lock(&curr->lock);
    pthread_mutex_unlock(&list->lock);

    node* node1 = NULL, * node2 = NULL;

    while (curr) {
        // If we found one of the values – remember the node and do not unlock it

        if (curr->value == val1 || curr->value == val2) {
            if (!node1) {
                node1 = curr;
            }
            else {
                node2 = curr;
                break; // both values were found
            }
        }

        node* next = curr->next;
        if (next) pthread_mutex_lock(&next->lock);

        // Unlock the current node only if it is not node1 or node2

        if (curr != node1 && curr != node2)
            pthread_mutex_unlock(&curr->lock);

        curr = next;
    }

    // swap if both nodes were found

    if (node1 && node2) {
        int tmp = node1->value;
        node1->value = node2->value;
        node2->value = tmp;
    }

    // Unlocking the locks of the nodes that were saved

    if (node1) pthread_mutex_unlock(&node1->lock);
    if (node2 && node2 != node1) pthread_mutex_unlock(&node2->lock);

    // If there's a remaining curr node that was locked and hasn't been unlocked – unlock it
   // (This happens only if one of the values wasn't found and the loop ended without unlocking curr)

    if (curr && curr != node1 && curr != node2)
        pthread_mutex_unlock(&curr->lock);
}

